#!/bin/bash

# Chạy script này BÊN TRONG thư mục binaries/apache-mac/

echo "🚀 BẮT ĐẦU ĐÓNG GÓI PORTABLE CHO APACHE CORE..."

LIBS_DIR="lib"
mkdir -p "$LIBS_DIR"

# Hàm vá đường dẫn cho file nhị phân
patch_binary() {
    local target="$1"
    local prefix="$2" # Dùng @executable_path cho file bin, @loader_path cho file module
    
    if [ ! -f "$target" ]; then return; fi
    
    echo "🔍 Đang vá: $target"
    chmod +w "$target" 2>/dev/null
    
    # Quét các thư viện bị hardcode (Đặc biệt là từ LPSERVER hoặc /usr/local)
    local deps=$(otool -L "$target" | awk 'NR>1 {print $1}' | grep -E "LPSERVER|/usr/local|Workspace")

    for old_path in $deps; do
        local filename=$(basename "$old_path")
        local new_lib_path="$LIBS_DIR/$filename"

        # Nếu file thư viện chưa có trong thư mục lib/ của Apache, tiến hành copy về
        if [ ! -f "$new_lib_path" ]; then
            if [ -f "$old_path" ]; then
                echo "   📦 Copying: $filename"
                cp "$old_path" "$new_lib_path"
                chmod +w "$new_lib_path"
                
                # Sửa ID của thư viện vừa copy
                install_name_tool -id "@loader_path/$filename" "$new_lib_path" 2>/dev/null
            else
                echo "   ⚠️ Không tìm thấy file gốc: $old_path"
                continue
            fi
        fi

        # Trỏ đường dẫn trong file target sang thư mục lib/ nội bộ
        install_name_tool -change "$old_path" "$prefix/$filename" "$target" 2>/dev/null
    done
    
    # Ký lại chữ ký số
    codesign -s - --force "$target" >/dev/null 2>&1
}

# 1. Vá trái tim của Apache (httpd)
# Lùi lại 1 cấp từ bin/ xuống thư mục gốc, rồi chui vào lib/
patch_binary "bin/httpd" "@executable_path/../lib"

# Nếu anh có xài htpasswd hoặc ab thì vá luôn
patch_binary "bin/htpasswd" "@executable_path/../lib"
patch_binary "bin/ab" "@executable_path/../lib"

# 2. Vá TẤT CẢ các module nội bộ của Apache (mod_rewrite.so, mod_ssl.so...)
# Lùi lại 2 cấp từ modules/ xuống thư mục gốc, rồi chui vào lib/
for mod in modules/*.so; do
    if [ -f "$mod" ] && [[ "$mod" != *"libphp"* ]]; then
        patch_binary "$mod" "@loader_path/../lib"
    fi
done

# 3. Ký nốt chữ ký số cho các thư viện vừa gom
for dylib in "$LIBS_DIR"/*.dylib; do
    if [ -f "$dylib" ]; then
        codesign -s - --force "$dylib" >/dev/null 2>&1
    fi
done

echo "✅ HOÀN TẤT! Apache đã được bốc thuốc Portable."
echo "Kiểm tra lại trái tim httpd:"
otool -L bin/httpd